<template>
  <aside class="side-bar-flight ">
    <flight-count :flight_count='flight_count'/>
    <div class="parent-name-ticket">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--! Font Awesome Pro 6.3.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M64 112c-8.8 0-16 7.2-16 16V384c0 8.8 7.2 16 16 16H576c8.8 0 16-7.2 16-16V349c-41.4-10.7-72-48.2-72-93s30.6-82.3 72-93V128c0-8.8-7.2-16-16-16H64zM0 128C0 92.7 28.7 64 64 64H576c35.3 0 64 28.7 64 64v61.3c0 11.2-12.8 18.7-24 18.7c-26.5 0-48 21.5-48 48s21.5 48 48 48c11.2 0 24 7.5 24 18.7V384c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V128zm432 16a16 16 0 1 1 0 32 16 16 0 1 1 0-32zm0 64a16 16 0 1 1 0 32 16 16 0 1 1 0-32zm-16 80a16 16 0 1 1 32 0 16 16 0 1 1 -32 0zm16 48a16 16 0 1 1 0 32 16 16 0 1 1 0-32zM186.7 224l-23.2-69.5c-1.7-5.2 2.1-10.5 7.6-10.5h31.1c8.5 0 16.4 4.5 20.7 11.9L262.7 224h40.3c16.1 0 31.5 6.4 42.8 17.7c7.9 7.9 7.9 20.7 0 28.5C334.4 281.6 319 288 302.9 288H262.7l-39.7 68.1c-4.3 7.4-12.2 11.9-20.7 11.9H171.1c-5.5 0-9.3-5.4-7.6-10.5L186.7 288H144l-19.2 25.6c-3 4-7.8 6.4-12.8 6.4H98.2c-5.2 0-9-4.9-7.8-9.9L103 259.9c.6-2.5 .6-5.2 0-7.8L90.5 201.9c-1.3-5 2.6-9.9 7.8-9.9H112c5 0 9.8 2.4 12.8 6.4L144 224h42.7z"></path></svg>
      <h4>{{ useXmltag('FlightTicket')}} {{ dataSearch.name_departure }} {{ useXmltag('On')}} {{ dataSearch.name_arrival }}</h4>
    </div>
    <div class="filter-side-bar">
      <h2>{{ useXmltag('Filters')}}</h2>
      <range-filter :type='type'/>
      <interrupt-filter v-if="type == 'international'"/>
      <type-filter/>
      <class-filter/>
      <airline-filter :type='type'/>
      <time-move-filter/>
    </div>

  </aside>
</template>

<script>

import flightCount from './flightCount'
import rangeFilter from './filters/range'
import typeFilter from './filters/type'
import classFilter from './filters/seatclass'
import airlineFilter from './filters/airline'
import timeMoveFilter from './filters/timeMove'
import interruptFilter from './filters/interrupt'
export default  {
  name : 'sideFilter' ,
  props :['flight_count' , 'type'],
  components: {
    'flight-count': flightCount,
    'range-filter': rangeFilter,
    'type-filter': typeFilter,
    'class-filter': classFilter,
    'airline-filter': airlineFilter,
    'time-move-filter': timeMoveFilter,
    'interrupt-filter': interruptFilter,
  },
  data() {
    return {

    }
  },
  computed: {
    dataSearch() {
      return this.$store.state.setDataSearch.dataSearch
    }
  }
}
</script>