<template>
  <a href="javascript:" @click='sortFlightByTime()'>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.3.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M256 0c-13.3 0-24 10.7-24 24v80c0 13.3 10.7 24 24 24s24-10.7 24-24V49.4C383.6 61.3 464 149.2 464 256c0 114.9-93.1 208-208 208S48 370.9 48 256c0-43.3 13.2-83.5 35.8-116.8c7.5-11 4.6-25.9-6.4-33.3s-25.9-4.6-33.3 6.4C16.3 153.2 0 202.7 0 256C0 397.4 114.6 512 256 512s256-114.6 256-256S397.4 0 256 0zM193 159c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l80 80c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-80-80z"/></svg>
    <h4>{{ useXmltag('BaseStartTime')}}</h4>
  </a>
</template>

<script>
export default {
  name: 'time',
  props: [
    'type'
  ],
  data()  {
    return {
      time_sort_filter :'asc',
    }
  },
  methods: {
    sortFlightByTime() {
      if(this.time_sort_filter ==='desc') {
        this.time_sort_filter = 'asc';
      }else{
        this.time_sort_filter = 'desc';
      }
      if(this.type == 'international') {
        this.$store.commit('timeSortInternationalFlight', this.time_sort_filter);
      }else{
        this.$store.commit('timeSortFlight', this.time_sort_filter);
      }

    }
  }

}
</script>