<template>
   <div>
      <div class="filter-parent d-md-none">
         <div class="parent-filter-responsive-btn" @click="showModal = true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
               <!--! Font Awesome Pro 6.3.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
               <path
                  d="M310.8 64C333.5 64 352 82.46 352 105.2C352 115.6 348.1 125.7 340.1 133.3L247.1 233.4V415.4C247.1 433.4 233.4 448 215.4 448C208.1 448 202.7 446.1 197.4 442.6L121.1 392.8C110.7 385.4 104 372.8 104 359.4V233.4L11.02 133.3C3.936 125.7 0 115.6 0 105.2C0 82.46 18.46 64 41.23 64H310.8zM151.1 224V355.1L199.1 386.8V224C199.1 217.9 202.3 212.1 206.4 207.7L295.2 112H56.75L145.6 207.7C149.7 212.1 151.1 217.9 151.1 224H151.1zM488 392C501.3 392 512 402.7 512 416C512 429.3 501.3 440 488 440H344C330.7 440 320 429.3 320 416C320 402.7 330.7 392 344 392H488zM320 256C320 242.7 330.7 232 344 232H488C501.3 232 512 242.7 512 256C512 269.3 501.3 280 488 280H344C330.7 280 320 269.3 320 256zM488 72C501.3 72 512 82.75 512 96C512 109.3 501.3 120 488 120H408C394.7 120 384 109.3 384 96C384 82.75 394.7 72 408 72H488z" />
            </svg>
            <h4>فیلتر ها</h4>
         </div>
      </div>
      <div v-if="showModal" class="modal-cip modal-filter">
         <div class="parent-modal-cip">
            <div class="header-modal-cip">
               <h3>فیلتر ها</h3>
               <button @click="showModal = false">بستن</button>

            </div>
            <div class="body-modal-cip">
            <FilterPrice
               :price_cip_filter="price_cip_filter"
               @setPriceFilter="setPriceFilter" />
            </div>
            <div class="footer-modal-cip">
               <button @click="showModal = false">اعمال فیلتر</button>
            </div>
         </div>
      </div>
   </div>
</template>

<script>
import VueModal from "@kouts/vue-modal"
import "@kouts/vue-modal/dist/vue-modal.css"
import FilterPrice from "./FilterPrice.vue"

export default {
   name: "FilterMobile",
   components: {FilterPrice},
   data() {
      return {
         showModal: false,
      }
   },
   props: {
      price_cip_filter: {
         type: Array,
         default: () => []
      }
   },
   methods: {
      setPriceFilter(valuePrice, checkMinMax) {
         this.$emit('setPriceFilter', valuePrice, checkMinMax)
      }
   }
}
</script>
