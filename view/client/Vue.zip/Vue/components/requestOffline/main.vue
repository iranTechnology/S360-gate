<template>
  <div class='fullCapacity_div p-0'>
    <h3>{{ useXmltag('RequestOfflineInformMe') }}</h3>
    <button @click='modalRequestOffline()'>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--! Font Awesome Pro 6.1.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M249.5 296.7C261.2 328.5 262.4 363.2 253.1 395.8L251.9 399.7L21.4 315.8C10.03 311.7 1.976 301.5 .5931 289.5C-.7903 277.5 4.729 265.7 14.86 259L23.04 253.7C57.61 230.1 83.95 197.8 98.16 159L112.8 119C137.1 50.44 213.1 15.09 282.6 40.08C287.4 41.82 292.1 43.82 296.5 46.04C232.4 88.2 203.2 170.3 230.8 245.5L249.5 296.7zM279.6 285.8L260.8 234.6C234.7 163.3 271.4 84.41 342.8 58.43C414.1 32.46 493.2 69.21 519.3 140.5L538 191.7C552 229.9 577.8 262.7 611.6 285.3L625.4 294.5C635.4 301.2 640.8 312.1 639.4 324.9C637.9 336.9 629.9 346.1 618.6 351.1L321.1 459.4C309.8 463.5 297.1 460.9 288.3 452.7C279.5 444.5 276 432 279.3 420.5L283.9 404.6C295.1 365.6 293.6 323.1 279.6 285.8H279.6zM324.7 269.4C340.5 312.5 343.6 359.1 333.7 403.7L573 316.6C536.6 288.9 508.8 251.3 492.9 208.1L474.2 156.9C457.2 110.5 405.7 86.59 359.3 103.5C312.8 120.4 288.9 171.7 305.1 218.2L324.7 269.4zM480.8 480C459.6 480 440.8 469.9 429.1 454.1L545.2 411.9C545.3 413.2 545.3 414.5 545.3 415.8C545.3 451.3 516.4 480 480.8 480V480zM94.34 376.2L211.9 419.5C200.3 436.7 180.7 447.9 158.4 447.9C122.8 447.9 93.91 419.2 93.91 383.7C93.91 381.1 94.05 378.6 94.34 376.2z"/></svg>
      {{ useXmltag('InformMe') }}
    </button>
    <Modal v-model="showModal" :title="useXmltag('RequestOffline')"
           modal-class="modal-xl" :rtl=true wrapper-class="modal-wrapper">

      <request-modal :dataSearch='dataSearch'  :member="member" @close="closeModal()"></request-modal>
    </Modal>
  </div>
</template>
<script>
import VueModal from '@kouts/vue-modal';
import requestModal from './requestModal';

export default {
  components: {
    'Modal' : VueModal ,
    'request-modal' : requestModal
  },
  data() {
    return {
      showModal : false ,
      modalClass : "modal-lg" ,
      member : ''
    }
  },
  name: "requestOffline",
  props : ['dataSearch'] ,
  methods: {
    modalRequestOffline() {
      this.showModal = true
    },
    closeModal() {
      this.showModal = false
    },
    async getMember() {
        let _this = this
        await axios
          .post(
            amadeusPath + "ajax",
            {
              className: "members",
              method: "getMemberJson" ,
            },
            {
              "Content-Type": "application/json",
            }
          )
          .then(function (response) {

            if(response && response.data.result.status == 'success') {
              _this.member = response.data.result.data

            }else if(response && response.data.result.status == 'error') {
              _this.member = '';
            }
          })
    }

  },
  created() {
    this.getMember();
  }
}
</script>
