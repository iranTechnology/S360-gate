<div class="col-lg-2 col-md-6 col-sm-6 col-12 col_search">
    <div class="select inp-s-num adt box-of-count-passenger box-of-count-passenger-js">
        <input type="hidden" class="package-adult-js" name="adult_number_package" id="count_adult_package" value="1">
        <input type="hidden" class="package-child-js" name="child_number_package" id="count_child_package" value="0">
        <input type="hidden" class="package-infant-js" name="infant_number_package" id="count_infant_package" value="0">
        <div class="box-of-count-passenger-boxes box-of-count-package-passenger-boxes-js">
            <span class="text-count-passenger text-count-passenger-js">1 بزرگسال ,0 کودک ,0 نوزاد</span>
            <span class="fas fa-caret-down down-count-passenger"></span>
        </div>
        <div class="cbox-count-passenger cbox-package-count-passenger-js">
            <div class="col-xs-12 cbox-count-passenger-ch adult-number-js">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-6">
                        <div class="type-of-count-passenger"><h6> بزرگسال </h6> (بزرگتر از ۱۲
                            سال)
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-6">
                        <div class="num-of-count-passenger">
                            <i class="fa fa-plus counting-of-count-passenger add-to-count-passenger-js"></i>
                            <i class="number-count-js number-count counting-of-count-passenger" data-number="1" data-min="1" data-search="package" data-type="adult">1</i>
                            <i class="fa fa-minus counting-of-count-passenger minus-to-count-passenger-js"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 cbox-count-passenger-ch child-number-js">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-6">
                        <div class="type-of-count-passenger"><h6> کودک </h6>(بین 2 الی 12 سال)
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-6">
                        <div class="num-of-count-passenger">
                            <i class="fa fa-plus counting-of-count-passenger add-to-count-passenger-js"></i>
                            <i class="number-count-js number-count counting-of-count-passenger" data-number="0" data-min="0" data-search="package" data-type="child">0</i>
                            <i class="fa fa-minus counting-of-count-passenger minus-to-count-passenger-js"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 cbox-count-passenger-ch infant-number-js">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-6">
                        <div class="type-of-count-passenger"><h6> نوزاد </h6>(کوچکتر از 2 سال)
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-6">
                        <div class="num-of-count-passenger">
                            <i class="fa fa-plus counting-of-count-passenger add-to-count-passenger-js"></i>
                            <i class="number-count-js number-count counting-of-count-passenger" data-number="0" data-min="0" data-search="package" data-type="infant">0</i>
                            <i class="fa fa-minus counting-of-count-passenger minus-to-count-passenger-js"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="div_btn"><span class="btn btn-close ">تأیید</span></div>
        </div>
    </div>
</div>