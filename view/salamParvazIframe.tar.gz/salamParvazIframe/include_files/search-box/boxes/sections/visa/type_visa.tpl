<div class="col-lg-5 col-md-6 col-sm-6 col-12 col_search p-1">
 <div class="parent-input-search-box">
  <i class="parent-svg-input-search-box">
   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.3.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M384 48c8.8 0 16 7.2 16 16V448c0 8.8-7.2 16-16 16H64c-8.8 0-16-7.2-16-16V64c0-8.8 7.2-16 16-16H384zM64 0C28.7 0 0 28.7 0 64V448c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V64c0-35.3-28.7-64-64-64H64zM96 400c0 8.8 7.2 16 16 16H336c8.8 0 16-7.2 16-16s-7.2-16-16-16H112c-8.8 0-16 7.2-16 16zm33.3-176h39.1c1.6 30.4 7.7 53.8 14.6 70.8c-27.9-13.2-48.4-39.4-53.7-70.8zM224 304l-.3 0c-2.4-3.5-5.7-8.9-9.1-16.5c-6-13.6-12.4-34.3-14.2-63.5h47.1c-1.8 29.2-8.1 49.9-14.2 63.5c-3.4 7.6-6.7 13-9.1 16.5l-.3 0zm94.7-80c-5.3 31.4-25.8 57.6-53.7 70.8c6.8-17.1 12.9-40.4 14.6-70.8h39.1zm0-32H279.6c-1.6-30.4-7.7-53.8-14.6-70.8c27.9 13.2 48.4 39.4 53.7 70.8zM224 112l.3 0c2.4 3.5 5.7 8.9 9.1 16.5c6 13.6 12.4 34.3 14.2 63.5H200.5c1.8-29.2 8.1-49.9 14.2-63.5c3.4-7.6 6.7-13 9.1-16.5l.3 0zm-94.7 80c5.3-31.4 25.8-57.6 53.7-70.8c-6.8 17.1-12.9 40.4-14.6 70.8H129.3zM224 336a128 128 0 1 0 0-256 128 128 0 1 0 0 256z"/></svg>
  </i>
  <div class="caption-input-search-box">##EnterVisaType##</div>
  <select data-placeholder="##VisaType##" name="visa_type"
          id="visa_type"
          class="select2_in  select2-hidden-accessible visa-type-js"
          tabindex="-1" aria-hidden="true">
   <option selected="selected" value="">##VisaType##</option>
  </select>
 </div>
</div>