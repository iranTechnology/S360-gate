<div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12 col_search search_col">
<div class="form-group d-flex align-items-center">
    <i class="fas fa-calendar fa-lg mr-2"></i>

    <input autocomplete="off" class="init-shamsi-return-datepicker form-control check-out-date-international-js" data-type="international" id="endDateForExternalHotelInternational" name="endDateForExternalHotelInternational" placeholder="تاریخ خروج" readonly="" type="text"/>
</div>
</div>