<div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12 col_search search_col">
    <div class="form-group destination_start">
        <i class="fas fa-map-marker-alt fa-lg mr-1" style="padding-right:2px;"></i>

        <div class="s-u-in-out-wrapper raft raft-change change-bor w-100">
                <input autocomplete="off" class="inputSearchForeign w-100" id="autoComplateSearchIN" name="autoComplateSearchIN" onclick="openBoxPopular('hotel')" onkeyup="searchCity('hotel')" placeholder="انتخاب شهر" type="text" value=""/>
                <input id="autoComplateSearchIN_hidden" placeholder="انتخاب شهر" type="hidden" value=""/>
                <input id="autoComplateSearchIN_hidden_en" placeholder="انتخاب شهر" type="hidden" value=""/>
                <ul class="ul-inputSearch-externalHotel displayiN" id="listSearchCity"></ul>
            </div>
    </div>
</div>