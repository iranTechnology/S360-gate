<div class="col-lg-2 col-md-6 col-sm-6 col-12 col_search p-1">
<div class="parent-input-search-box">
<i class="parent-svg-input-search-box">
<svg viewbox="0 0 384 512" xmlns="://www.w3.org/2000/svg">
<!--! Font Awesome Pro 6.3.0 by @fontawesome - ://fontawesome.com License - ://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
<path d="M336 192c0-79.5-64.5-144-144-144S48 112.5 48 192c0 12.4 4.5 31.6 15.3 57.2c10.5 24.8 25.4 52.2 42.5 79.9c28.5 46.2 61.5 90.8 86.2 122.6c24.8-31.8 57.8-76.4 86.2-122.6c17.1-27.7 32-55.1 42.5-79.9C331.5 223.6 336 204.4 336 192zm48 0c0 87.4-117 243-168.3 307.2c-12.3 15.3-35.1 15.3-47.4 0C117 435 0 279.4 0 192C0 86 86 0 192 0S384 86 384 192zm-160 0a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm-112 0a80 80 0 1 1 160 0 80 80 0 1 1 -160 0z">
</path>
</svg>
</i>
<div class="caption-input-search-box">
شهر مقصد را وارد کنید
 </div>
<select aria-hidden="true" class="select2_in select2-hidden-accessible international-destination-city-tour-js" data-placeholder="مقصد ( شهر )" id="tourDestinationCityPortal" name="tourDestinationCityPortal" tabindex="-1">
<option value="">##ChoseOption##...</option>
</select>
</div>
</div>