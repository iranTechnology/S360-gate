<section class="i_modular_searchBox search_box mt-5 ">
    <div class="container">
        <div class="search_box_div">
            <ul class="__search_box_tabs__ nav" id="searchBoxTabs" >
                {include file="./search-box/tabs-search-box.tpl"}
                <li class="nav-item {if $smarty.const.GDS_SWITCH_PAGE eq 'visa' && $smarty.const.GDS_SWITCH eq 'page'} d-none {/if}">
                    <a
                            href="https://salamparvaz.com/tours"
                       class="{$tab_id}-tab-pic nav-link"
                            target="_blank"
                      >

                        <div>
                            <i>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                    <!--! Font Awesome Pro 6.3.0 -->
                                    <path d="M352.1 128h-32.07l.0123-80c0-26.47-21.53-48-48-48h-96c-26.47 0-48 21.53-48 48L128 128H96.12c-35.35 0-64 28.65-64 64v224c0 35.35 28.58 64 63.93 64L96 496C96 504.8 103.2 512 112 512S128 504.8 128 496V480h192v16c0 8.836 7.164 16 16 16s16-7.164 16-16l.0492-16c35.35 0 64.07-28.65 64.07-64V192C416.1 156.7 387.5 128 352.1 128zM160 48C160 39.17 167.2 32 176 32h96C280.8 32 288 39.17 288 48V128H160V48zM384 416c0 17.64-14.36 32-32 32H96c-17.64 0-32-14.36-32-32V192c0-17.64 14.36-32 32-32h256c17.64 0 32 14.36 32 32V416zM304 336h-160C135.2 336 128 343.2 128 352c0 8.836 7.164 16 16 16h160c8.836 0 16-7.164 16-16C320 343.2 312.8 336 304 336zM304 240h-160C135.2 240 128 247.2 128 256c0 8.836 7.164 16 16 16h160C312.8 272 320 264.8 320 256C320 247.2 312.8 240 304 240z"/>
                                </svg>
                            </i>
                            <h4>تور</h4>
                        </div>

                    </a>
                </li>
            </ul>
            <div class="__search_boxes__ tab-content" id="searchBoxContent" style="background:rgba(255,255,255,0.6);margin-top:3px">
                {include file="./search-box/boxs-search.tpl"}
            </div>
        </div>
    </div>
</section>


<style>
    .banner-slider-display {
        display: none;
    }
</style>